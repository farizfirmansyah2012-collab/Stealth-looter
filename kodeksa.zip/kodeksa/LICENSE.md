# WebKodexa Custom License

**Effective Date:** 1 Juli 2026

---

## 📋 Lisensi Penggunaan WebKodexa Template

Dokumen ini menjelaskan hak dan batasan penggunaan template WebKodexa.

---

## ✅ DIIZINKAN (Yang Boleh Dilakukan)

### 1. Penggunaan Bisnis/Komersial
- ✅ Menggunakan template untuk website bisnis Anda
- ✅ Menggunakan untuk project klien (freelance, agency)
- ✅ Menggunakan untuk tujuan komersial/profit
- ✅ Menggunakannya dalam produk atau layanan berbayar

### 2. Modifikasi & Kustomisasi
- ✅ Mengubah design sesuai kebutuhan
- ✅ Menambah fitur baru
- ✅ Menghapus fitur yang tidak perlu
- ✅ Mengubah warna, font, layout
- ✅ Mengintegrasikan dengan sistem lain

### 3. Penggunaan Personal
- ✅ Menggunakan untuk portfolio
- ✅ Menggunakan untuk belajar
- ✅ Menggunakan untuk project personal

---

## ❌ DILARANG (Yang Tidak Boleh Dilakukan)

### 1. Penjualan Ulang
- ❌ **DILARANG** menjual ulang template ini (as-is)
- ❌ **DILARANG** memasarkan sebagai template baru
- ❌ **DILARANG** membundel dan dijual kembali
- ❌ **DILARANG** menjual akses/subscription ke template ini

**Pengecualian:** Anda boleh **menjual hasil akhir/layanan** (website yang sudah dimodifikasi untuk klien)

### 2. Redistribusi/Upload Ulang
- ❌ **DILARANG** mengunggah ke GitHub, GitLab, atau platform publik lain
- ❌ **DILARANG** membagikan source code secara publik
- ❌ **DILARANG** mengunggah ke situs template (Themeforest, Envato, dll)
- ❌ **DILARANG** membagikan link download ke komunitas/forum

**Pengecualian:** Boleh share untuk team internal/klien dengan NDA

### 3. Penghapusan Atribusi
- ❌ **DILARANG** menghapus credit/watermark creator (jika ada)
- ❌ **DILARANG** mengklaim sebagai karya sendiri
- ❌ **DILARANG** menghapus notice lisensi

---

## 📌 KONDISI UMUM

### Penggunaan "As-Is"
Template disediakan "ASIS" tanpa garansi. Pembuat tidak bertanggung jawab atas:
- Bug atau error
- Kompatibilitas di berbagai browser
- Hasil akhir website Anda
- Kerusakan atau kehilangan data

### Kompatibilitas Browser
Template dioptimalkan untuk browser modern:
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### Support & Update
- Tidak ada garansi update atau maintenance
- Creator tidak wajib memberikan technical support
- Bug fixes dan update bersifat voluntary

---

## 📄 SKENARIO PENGGUNAAN

### ✅ Diizinkan

| Skenario | Status |
|----------|--------|
| Menggunakan untuk website bisnis sendiri | ✅ OK |
| Memodifikasi untuk kebutuhan klien | ✅ OK |
| Menggunakan fitur untuk project lain | ✅ OK |
| Menggabung dengan kode lain | ✅ OK |
| Menggunakan untuk internal company | ✅ OK |
| Menjual hasil akhir ke klien | ✅ OK |

### ❌ Dilarang

| Skenario | Status |
|----------|--------|
| Menjual template ini secara langsung | ❌ NO |
| Unggah ke Themeforest/marketplace lain | ❌ NO |
| Share source code secara publik | ❌ NO |
| Klaim sebagai karya sendiri | ❌ NO |
| Jual sebagai premium template | ❌ NO |
| Unggah ke GitHub public | ❌ NO |

---

## 🔐 Pembayaran & Kepemilikan

1. **Harga Lisensi** - One-time payment
   - Pembayaran satu kali untuk unlimited usage
   - Tidak ada recurring fee
   - Tidak ada subscription

2. **Kepemilikan IP**
   - Creator tetap memiliki hak intellectual property
   - Anda memiliki hak untuk menggunakan sesuai lisensi
   - Modified version tetap harus mengikuti lisensi ini

3. **Komersial Rights**
   - Anda bisa komersialkan hasil akhir
   - Anda bisa charge klien untuk services
   - Klien tidak boleh diberi source code (kecuali custom agreement)

---

## ⚖️ PELANGGARAN LISENSI

Jika terjadi pelanggaran lisensi:

1. **Notifikasi** - Creator akan memberikan notifikasi
2. **Compliance Period** - Maksimal 30 hari untuk compliance
3. **Action** - Jika tidak comply, legal action dapat diambil

Pelanggaran termasuk:
- Penjualan ulang template
- Upload ke public repository
- Mengklaim sebagai creator
- Redistribusi tanpa izin

---

## 📞 KONTRAK & AGREEMENT

Untuk custom arrangement atau pengecualian, hubungi:

- **Email:** support@webkodexa.com
- **Contact:** [Your Contact Info]

Semua arrangement harus dalam bentuk **written agreement** yang ditandatangani.

---

## 🔄 PERUBAHAN LISENSI

Creator berhak mengubah lisensi untuk versi future, tetapi:
- Tidak mempengaruhi versi yang sudah dibeli
- Notifikasi akan diberikan sebelum update
- Perubahan tidak berlaku retroaktif

---

## 📋 RINGKASAN CEPAT

| Aspek | Izin |
|-------|------|
| **Komersial Use** | ✅ Yes |
| **Modifikasi** | ✅ Yes |
| **Personal Use** | ✅ Yes |
| **Team/Internal** | ✅ Yes |
| **Resale** | ❌ No |
| **Public Share** | ❌ No |
| **Claim Ownership** | ❌ No |

---

## ✍️ PENERIMAAN

Dengan menggunakan template ini, Anda:
- ✅ Setuju dengan semua syarat lisensi
- ✅ Memahami larangan yang berlaku
- ✅ Menerima template "as-is"
- ✅ Melepas creator dari tanggung jawab legal

---

**Version:** 1.0  
**Last Updated:** 1 Juli 2026  
**Creator:** WebKodexa Team

Untuk pertanyaan atau clarifikasi, silakan hubungi kami.

---

*Lisensi ini adalah legal binding document. Pastikan Anda membaca dan memahami sebelum menggunakan template.*
