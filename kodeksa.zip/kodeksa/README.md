# 📚 WebKodexa - Kamus Pemrograman Web

Referensi lengkap untuk mempelajari HTML, CSS, dan JavaScript dalam satu tempat yang interaktif dan menarik.

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Status](https://img.shields.io/badge/status-Active-brightgreen)

---

## ✨ Fitur Utama

### 🎨 **Dark Mode & Customizable Theme**
- Toggle dark/light mode dengan satu klik
- Pilih warna latar belakang sesuai keinginan menggunakan color picker
- Teks secara otomatis menyesuaikan kontras untuk aksesibilitas optimal
- Penyimpanan preferensi di localStorage (persisten di browser)

### 📖 **Kamus Lengkap**
- **40+ Tag HTML** - Semua tag HTML5 dengan penjelasan
- **30+ Property CSS** - Property CSS populer dengan contoh
- **30+ Fungsi JavaScript** - Fungsi JS esensial dengan implementasi

### 🎯 **Fitur Interaktif**
- **Favorit** - Tandai istilah yang sering digunakan
- **Tersimpan** - Koleksi materi favorit Anda
- **Ujian Acak** - Tes kemampuan dengan soal lintas topik

### 🎬 **Animasi & Visual**
- Scroll reveal animations untuk kartu konten
- Hero section dengan gradient title berwarna
- Loading screen yang smooth
- Responsive design untuk semua ukuran layar
- Transisi dan hover effects yang premium

---

## 🚀 Quick Start

### Prerequisites
- Browser modern (Chrome, Firefox, Safari, Edge)
- Tidak perlu instalasi atau build process

### Cara Membuka
1. Clone atau download repository ini
2. Buka file `template/index.html` di browser
3. Nikmati pengalaman browsing yang interaktif

```bash
# Cukup buka di browser
open template/index.html
```

---

## 📁 Struktur Project

```
kodeksa/
├── template/
│   └── index.html          # File utama halaman
├── static/
│   ├── style.css           # Stylesheet
│   └── script.js           # JavaScript logic
├── font/
│   └── *.ttf              # Custom fonts
├── asset/
│   ├── fitur/             # Icon fitur
│   └── kamus/             # Icon kamus
└── README.md              # Dokumentasi
```

---

## 🛠️ Teknologi yang Digunakan

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling dengan variables, grid, flexbox
- **Vanilla JavaScript** - No dependencies, pure JS ES6+

### Key Libraries/APIs
- **Intersection Observer API** - Untuk scroll reveal animations
- **localStorage API** - Untuk penyimpanan preferensi user
- **CSS Custom Properties** - Untuk dynamic theming

### Fonts
- **Syne** - Font heading (modern & bold)
- **DM Sans** - Font body (clean & readable)
- **JetBrains Mono** - Font monospace (code)
- **Inter** - Font alternatif

---

## 💻 Fitur Detail

### 1. Dark Mode & Color Customization
```javascript
// User bisa memilih warna background
// Sistem otomatis menghitung luminance
// Jika background terang → text gelap
// Jika background gelap → text terang
```

**Penggunaan:**
- Klik tombol 🎨 di navbar kanan atas
- Pilih warna yang diinginkan
- Preferensi tersimpan otomatis

### 2. Scroll Reveal Animation
- Setiap kartu muncul saat masuk viewport
- Animasi staggered (cascade effect)
- Smooth cubic-bezier easing

### 3. Responsive Design
- Grid 3 kolom untuk kamus (desktop)
- Grid 2 kolom untuk fitur (desktop)
- Menyesuaikan otomatis di mobile
- Font size responsive dengan `clamp()`

### 4. Navbar Fixed
- Navbar tetap di atas saat scroll
- Contains logo, navigation dots, dan theme toggle
- Design yang clean dan modern

---

## 🎨 Customization Guide

### Mengubah Warna Default
Edit di `static/style.css`, bagian `:root`:

```css
:root {
  --bg: #0C0F1A;           /* Background utama */
  --surface: #1318267f;    /* Surface cards */
  --text: #E8ECF5;         /* Text warna terang */
  --text2: #7A8AAA;        /* Text secondary */
  --text3: #3A4560;        /* Text tertiary */
  --html: #E85D3A;         /* HTML color */
  --css: #3B82F6;          /* CSS color */
  --js: #EAB308;           /* JavaScript color */
}
```

### Menambah Card Baru
Tambahkan di HTML dengan class `.mcard`:

```html
<a href="link" class="mcard" style="--ac:var(--html);--ibg:rgba(232,93,58,0.1)">
  <div class="card-icon">🏷️</div>
  <div class="card-tag">Tag Baru</div>
  <h3>Nama Card</h3>
  <p>Deskripsi singkat</p>
  <span class="card-arrow">↗</span>
</a>
```

### Mengubah Font
Ganti di `@font-face` atau update CSS variables

---

## 📊 Browser Support

| Browser | Support |
|---------|---------|
| Chrome  | ✅ Full |
| Firefox | ✅ Full |
| Safari  | ✅ Full |
| Edge    | ✅ Full |
| IE 11   | ❌ No  |

---

## 🔧 Troubleshooting

### Animasi tidak muncul?
- Periksa browser cache (Ctrl+Shift+R)
- Pastikan JavaScript tidak diblock

### Warna tidak berubah?
- Clear localStorage: `localStorage.clear()`
- Refresh halaman

### Font tidak load?
- Periksa path ke folder `font/`
- Pastikan font file ada

---

## 📝 Performance Tips

1. **Lazy Loading** - Images bisa di-lazy load untuk kecepatan
2. **Minify CSS/JS** - Untuk production, minify files
3. **Compress Images** - Optimalkan ukuran asset
4. **CDN** - Pertimbangkan untuk custom fonts

---

## 🎓 Learning Resources

Kamus ini mencakup:
- Definisi dan penjelasan
- Contoh penggunaan
- Dokumentasi resmi link
- Use cases praktis

---

## 📄 License

MIT License - Bebas digunakan untuk komersial maupun non-komersial

---

## 🤝 Kontribusi

Punya saran atau menemukan bug? Silakan buat issue atau pull request!

---

## 📧 Contact

Untuk pertanyaan atau custom development, hubungi kami melalui:
- Email: support@webkodexa.com
- Issues: Buat di repository

---

## 🙏 Credits

Dibuat dengan ❤️ untuk web developers Indonesia

**Last Updated:** 1 Juli 2026

email:farizfirmansyah2012@gmail.com
