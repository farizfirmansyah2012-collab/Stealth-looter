(function() {
  const LOADING_FLAG = 'webkodexa_loading_done';
  const loader = document.getElementById('loadingScreen');

  // Jika flag sudah ada (pernah loading), langsung sembunyikan loading tanpa efek
  if (localStorage.getItem(LOADING_FLAG) === 'true') {
    if (loader) loader.style.display = 'none';
    return;
  }

  // Belum pernah loading, tampilkan loading (pastikan visible)
  if (!loader) return;

  // Tunggu semua konten halaman (termasuk gambar, font, dll) selesai
  window.addEventListener('load', function() {
    // Beri jeda minimal agar loading terlihat (opsional, sesuai keinginan)
    setTimeout(function() {
      loader.style.opacity = '0';
      setTimeout(function() {
        loader.style.display = 'none';
        // Set flag setelah loading selesai
        localStorage.setItem(LOADING_FLAG, 'true');
      }, 300);
    }, 800); // durasi minimal loading (sesuaikan)
  });
})();
var n = JSON.parse(localStorage.getItem('allSaves')||'[]').length;
if(n > 0){
  var b = document.getElementById('savedBadge');
  b.textContent = n;
  b.style.display = 'inline';
}

var n = JSON.parse(localStorage.getItem('allLikes')||'[]').length;
if(n > 0){
  var b = document.getElementById('likedBadge');
  b.textContent = n;
  b.style.display = 'inline';
}

const darkModeBtn = document.getElementById("darkModeBtn");
const body = document.body;
const picker = document.getElementById("cp");

// Fungsi untuk menghitung luminance warna (brightness)
function getLuminance(color) {
  // Convert hex atau rgb ke RGB values
  let r, g, b;
  
  if (color.startsWith('#')) {
    // Hex color
    const hex = color.replace('#', '');
    r = parseInt(hex.substring(0, 2), 16);
    g = parseInt(hex.substring(2, 4), 16);
    b = parseInt(hex.substring(4, 6), 16);
  } else if (color.startsWith('rgb')) {
    // RGB color
    const rgb = color.match(/\d+/g);
    r = parseInt(rgb[0]);
    g = parseInt(rgb[1]);
    b = parseInt(rgb[2]);
  } else {
    return 0.5; // Default to medium brightness
  }
  
  // Calculate relative luminance menggunakan formula WCAG
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance;
}

// Fungsi untuk mengatur text color berdasarkan background
function setTextColor(bgColor) {
  const luminance = getLuminance(bgColor);
  
  // Jika luminance > 0.5 (warna terang), gunakan text gelap
  // Jika luminance <= 0.5 (warna gelap), gunakan text terang
  if (luminance > 0.5) {
    // Light background - dark text
    document.documentElement.style.setProperty('--text', '#1a1a1a');
    document.documentElement.style.setProperty('--text2', '#4a4a4a');
    document.documentElement.style.setProperty('--text3', '#6b6b6b');
  } else {
    // Dark background - light text
    document.documentElement.style.setProperty('--text', '#E8ECF5');
    document.documentElement.style.setProperty('--text2', '#7A8AAA');
    document.documentElement.style.setProperty('--text3', '#3A4560');
  }
}

// Load tema yang disimpan dari localStorage
const savedBgColor = localStorage.getItem('bgColor');

if (savedBgColor) {
  body.style.background = savedBgColor;
  setTextColor(savedBgColor);
} else {
  // Apply default dark text color
  setTextColor(getComputedStyle(body).backgroundColor);
}

// Saat tombol tema ditekan
darkModeBtn.onclick = function(e){
  e.stopPropagation();
  // Buka pemilih warna
  picker.click();
}

// Saat pengguna memilih warna
picker.oninput = function(){
  const selectedColor = picker.value;
  body.style.background = selectedColor;
  setTextColor(selectedColor);
  
  // Simpan ke localStorage
  localStorage.setItem('bgColor', selectedColor);
}

// Scroll Reveal Animation
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const scrollObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const element = entry.target;
            
            // Jika element adalah card grid
            if (element.classList.contains('cards-grid')) {
                const cards = element.querySelectorAll('.mcard');
                cards.forEach((card, index) => {
                    setTimeout(() => {
                        card.classList.add('show');
                    }, index * 100);
                });
                scrollObserver.unobserve(element);
            } else {
                // Untuk element lainnya
                element.classList.add('show');
                scrollObserver.unobserve(element);
            }
        }
    });
}, observerOptions);

// Observer untuk card grids
const cardGrids = document.querySelectorAll('.cards-grid');
cardGrids.forEach(grid => scrollObserver.observe(grid));

// Observer untuk section lainnya yang bisa di-reveal
const revealElements = document.querySelectorAll('.hero, .divider, .stats-row');
revealElements.forEach(el => scrollObserver.observe(el));
